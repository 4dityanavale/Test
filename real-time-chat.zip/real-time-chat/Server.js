const WebSocket = require('ws');
const express = require('express');
const http = require('http');
const path = require('path');

const PORT = 8080;

// Initialize Express
const app = express();
const server = http.createServer(app);

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Create a WebSocket server
const wss = new WebSocket.Server({ server });

wss.on('connection', (socket) => {
    console.log('A new client connected');

    // Handle incoming messages from a client
    socket.on('message', (message) => {
        console.log(`Received: ${message}`);

        // Broadcast the message to all connected clients
        wss.clients.forEach((client) => {
            if (client.readyState === WebSocket.OPEN) {
                client.send(message); // Send plain text
            }
        });
    });

    // Handle client disconnection
    socket.on('close', () => {
        console.log('A client disconnected');
    });
});

// Start the server
server.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
